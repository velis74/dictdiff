(function (jsGrid, $, undefined) {

  var TextField = jsGrid.TextField;

  function Select2Field(config) {
    this.items         = [];
    this.selectedIndex = -1;
    this.valueField    = "";
    this.textField     = "";
    this.imgField      = "";
    this.groupField    = "";
    this.placeholder   = "";

    if (config.valueField && config.items.length)
      this.valueType = typeof config.items[0][config.valueField];
    this.sorter = this.valueType;
    TextField.call(this, config);
  }

  Select2Field.prototype = new TextField({
    align:     "left",
    valueType: "text",

    itemTemplate: function (value) {
      var items       = this.items,
          valueField  = this.valueField,
          textField   = this.textField,
          imgField    = this.imgField,
          groupField  = this.groupField,
          placeholder = this.placeholder,
          resultItem;

      if (valueField) {
        resultItem = $.grep(items, function (item, index) {
              return item[valueField] == value;
            })[0] || {};
      }
      else
        resultItem = items[value];

      var result = (textField ? resultItem[textField] : resultItem),
          img    = (imgField ? resultItem[imgField] : '');
      if (result === undefined || result === null)
        result = placeholder;
      img = (img === undefined || img === null) ? "" : '<img src="' + img + '"/> ';

      return img + result;
    },

    filterTemplate: function () {
      if (!this.filtering)
        return "";

      var grid    = this._grid,
          $result = this.filterControl = this._createSelect();
      this._applySelect($result, this);

      if (this.autosearch) {
        $result.on("change", function (e) {
          grid.search();
        });
      }

      return $result;
    },

    insertTemplate: function () {
      if (!this.inserting)
        return "";

      var $result = this.insertControl = this._createSelect();
      this._applySelect($result, this);
      return $result;
    },

    editTemplate: function (value) {
      if (!this.editing)
        return this.itemTemplate(value);

      var $result = this.editControl = this._createSelect();
      (value !== undefined) && $result.val(value);
      this._applySelect($result, this);
      return $result;
    },

    filterValue: function () {
      return this.filterControl.val();
    },

    insertValue: function () {
      return this.insertControl.val();
    },

    editValue: function () {
      return this.editControl.val();
    },

    _applySelect: function (item, self) {
      setTimeout(function () {
        var selectSiteIcon = function (opt) {
          var img = '';
          try {
            img = opt.element.attributes.img.value;
          } catch (e) {}
          if (!opt.id || !img)
            return opt.text;
          return $('<span><img src="' + img + '" class="img-flag"/> ' + opt.text + '</span>');
        };
        var s2p            = {
          width:             self.width,
          templateResult:    selectSiteIcon,
          templateSelection: selectSiteIcon
        };
        if (self.placeholder != "")
          $.extend(s2p, {
            placeholder: self.placeholder,
            allowClear:  true
          });
        item.select2(s2p);
      }, 0);
    },

    _createSelect: function () {
      var $result       = $("<select>"),
          valueField    = this.valueField,
          textField     = this.textField,
          imgField      = this.imgField,
          groupField    = this.groupField,
          selectedIndex = this.selectedIndex;

      var lastGroup = null;
      var $group    = $result;
      $.each(this.items, function (index, item) {
        var value = valueField ? item[valueField] : index,
            text  = textField ? item[textField] : item,
            img   = imgField ? item[imgField] : '',
            group = groupField ? item[groupField] : null;

        if (group != lastGroup) {
          $group    = $('<optgroup>')
              .attr('label', group)
              .appendTo($result);
          lastGroup = group;
        }

        var $option;
        if (value == null && text == null)
          $option = $("<option>")
              .appendTo($group);
        else
          $option = $("<option>")
              .attr("value", value)
              .attr("img", img)
              .text(text)
              .appendTo($group);

        $option.prop("selected", (selectedIndex === index));
      });

      return $result;
    }
  });

  jsGrid.fields.select2 = jsGrid.Select2Field = Select2Field;

}(jsGrid, jQuery));

(function (jsGrid, $, undefined) {

  var NumberField = jsGrid.NumberField;

  function SelectmenuField(config) {
    this.items         = [];
    this.selectedIndex = -1;
    this.valueField    = "";
    this.textField     = "";
    this.imgField      = "";

    if (config.valueField && config.items.length)
      this.valueType = typeof config.items[0][config.valueField];
    this.sorter = this.valueType;
    NumberField.call(this, config);
  }

  SelectmenuField.prototype = new NumberField({
    align:     "left",
    valueType: "number",
    onChange: $.noop,

    itemTemplate: function (value) {
      var items      = this.items,
          valueField = this.valueField,
          textField  = this.textField,
          imgField   = this.imgField,
          resultItem;

      if (valueField) {
        resultItem = $.grep(items, function (item, index) {
              return item[valueField] == value;
            })[0] || {};
      }
      else
        resultItem = items[value];

      var result = (textField ? resultItem[textField] : resultItem);
      return (result === undefined || result === null) ? "" : result;
    },

    filterTemplate: function () {
      var self = this;
      if (!this.filtering)
        return "";

      var grid    = this._grid,
          $result = this.filterControl = this._createSelect(true);

      setTimeout(function () { $result.selectmenu({width: self.width, change: self.onChange}); }, 0);

      if (this.autosearch) {
        $result.on("change", function (e) {
          grid.search();
        });
      }

      return $result;
    },

    insertTemplate: function () {
      var self = this;
      if (!this.inserting)
        return "";

      var $result = this.insertControl = this._createSelect();
      setTimeout(function () { $result.selectmenu({width: self.width, change: self.onChange}); }, 0);
      return $result;
    },

    editTemplate: function (value) {
      var self = this;
      if (!this.editing)
        return this.itemTemplate(value);

      var $result = this.editControl = this._createSelect();
      (value !== undefined) && $result.val(value);
      setTimeout(function () { $result.selectmenu({width: self.width, change: self.onChange}); }, 0);
      return $result;
    },

    filterValue: function () {
      var val = this.filterControl.val();
      return this.valueType === "number" && val !== '' ? parseInt(val || 0, 10) : val;
    },

    insertValue: function () {
      var val = this.insertControl.val();
      return this.valueType === "number" ? parseInt(val || 0, 10) : val;
    },

    editValue: function () {
      var val = this.editControl.val();
      return this.valueType === "number" ? parseInt(val || 0, 10) : val;
    },

    _createSelect: function (addPlaceholder) {
      var $result       = $("<select>"),
          valueField    = this.valueField,
          textField     = this.textField,
          selectedIndex = this.selectedIndex;

      var items = this.items.slice();
      if (addPlaceholder === true) {
        var tmp = {};
        tmp[valueField] = '';
        tmp[textField] = '-----------';
        items.unshift(tmp);
      }
      $.each(items, function (index, item) {
        var value = valueField ? item[valueField] : index,
            text  = textField ? item[textField] : item;

        var $option = $("<option>")
            .attr("value", value)
            .text(text)
            .appendTo($result);

        $option.prop("selected", (selectedIndex === index));
      });
      return $result;
    }
  });

  jsGrid.fields.selectmenu = jsGrid.SelectmenuField = SelectmenuField;

}(jsGrid, jQuery));

(function (jsGrid, $, undefined) {

  //http://jacwright.com/projects/javascript/date_format/ (MIT license)
  Date.prototype.format = function (format) {
    var returnStr = '';
    var replace   = Date.replaceChars;
    for (var i = 0; i < format.length; i++) {
      var curChar = format.charAt(i);
      if (i - 1 >= 0 && format.charAt(i - 1) == "\\")
        returnStr += curChar;
      else if (replace[curChar])
        returnStr += replace[curChar].call(this);
      else if (curChar != "\\")
        returnStr += curChar;
    }
    return returnStr;
  };

  Date.replaceChars = {
    shortMonths: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    longMonths:  ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    shortDays:   ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    longDays:    ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],

    // Day
    d: function () { return (this.getDate() < 10 ? '0' : '') + this.getDate(); },
    D: function () { return Date.replaceChars.shortDays[this.getDay()]; },
    j: function () { return this.getDate(); },
    l: function () { return Date.replaceChars.longDays[this.getDay()]; },
    N: function () { return this.getDay() + 1; },
    S: function () { return (this.getDate() % 10 == 1 && this.getDate() != 11 ? 'st' : (this.getDate() % 10 == 2 && this.getDate() != 12 ? 'nd' : (this.getDate() % 10 == 3 && this.getDate() != 13 ? 'rd' : 'th'))); },
    w: function () { return this.getDay(); },
    z: function () {
      var d = new Date(this.getFullYear(), 0, 1);
      return Math.ceil((this - d) / 86400000);
    }, // Fixed now
    // Week
    W: function () {
      var d = new Date(this.getFullYear(), 0, 1);
      return Math.ceil((((this - d) / 86400000) + d.getDay() + 1) / 7);
    }, // Fixed now
    // Month
    F: function () { return Date.replaceChars.longMonths[this.getMonth()]; },
    m: function () { return (this.getMonth() < 9 ? '0' : '') + (this.getMonth() + 1); },
    M: function () { return Date.replaceChars.shortMonths[this.getMonth()]; },
    n: function () { return this.getMonth() + 1; },
    t: function () {
      var d = new Date();
      return new Date(d.getFullYear(), d.getMonth(), 0).getDate()
    }, // Fixed now, gets #days of date
    // Year
    L: function () {
      var year = this.getFullYear();
      return (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0));
    },   // Fixed now
    o: function () {
      var d = new Date(this.valueOf());
      d.setDate(d.getDate() - ((this.getDay() + 6) % 7) + 3);
      return d.getFullYear();
    }, //Fixed now
    Y: function () { return this.getFullYear(); },
    y: function () { return ('' + this.getFullYear()).substr(2); },
    // Time
    a: function () { return this.getHours() < 12 ? 'am' : 'pm'; },
    A: function () { return this.getHours() < 12 ? 'AM' : 'PM'; },
    B: function () { return Math.floor((((this.getUTCHours() + 1) % 24) + this.getUTCMinutes() / 60 + this.getUTCSeconds() / 3600) * 1000 / 24); }, // Fixed now
    g: function () { return this.getHours() % 12 || 12; },
    G: function () { return this.getHours(); },
    h: function () { return ((this.getHours() % 12 || 12) < 10 ? '0' : '') + (this.getHours() % 12 || 12); },
    H: function () { return (this.getHours() < 10 ? '0' : '') + this.getHours(); },
    i: function () { return (this.getMinutes() < 10 ? '0' : '') + this.getMinutes(); },
    s: function () { return (this.getSeconds() < 10 ? '0' : '') + this.getSeconds(); },
    u: function () {
      var m = this.getMilliseconds();
      return (m < 10 ? '00' : (m < 100 ?
              '0' : '')) + m;
    },
    // Timezone
    e: function () { return "Not Yet Supported"; },
    I: function () {
      var DST = null;
      for (var i = 0; i < 12; ++i) {
        var d      = new Date(this.getFullYear(), i, 1);
        var offset = d.getTimezoneOffset();

        if (DST === null) DST = offset;
        else if (offset < DST) {
          DST = offset;
          break;
        } else if (offset > DST) break;
      }
      return (this.getTimezoneOffset() == DST) | 0;
    },
    O: function () { return (-this.getTimezoneOffset() < 0 ? '-' : '+') + (Math.abs(this.getTimezoneOffset() / 60) < 10 ? '0' : '') + (Math.abs(this.getTimezoneOffset() / 60)) + '00'; },
    P: function () { return (-this.getTimezoneOffset() < 0 ? '-' : '+') + (Math.abs(this.getTimezoneOffset() / 60) < 10 ? '0' : '') + (Math.abs(this.getTimezoneOffset() / 60)) + ':00'; }, // Fixed now
    T: function () {
      var m = this.getMonth();
      this.setMonth(0);
      var result = this.toTimeString().replace(/^.+ \(?([^\)]+)\)?$/, '$1');
      this.setMonth(m);
      return result;
    },
    Z: function () { return -this.getTimezoneOffset() * 60; },
    // Full Date/Time
    c: function () { return this.format("Y-m-d\\TH:i:sP"); }, // Fixed now
    r: function () { return this.toString(); },
    U: function () { return this.getTime() / 1000; }
  };

  var TextField = jsGrid.TextField;

  function DateField(config) {
    this.format        = "d.m.Y H:i:s";
    TextField.call(this, config);
  }

  DateField.prototype = new TextField({
    align:     "left",
    valueType: "text",

    sorter: function(date1, date2) {
      return new Date(date1) - new Date(date2);
    },

    itemTemplate: function (value) {
      return value != null && value != "" ? new Date(value).format(this.format) : "";
    },

    editTemplate: function(value) {
      if (value == undefined || value == null)
          value = '';
      if(!this.editing)
          return this.itemTemplate(value);
      value = value != null && value != "" ? new Date(value).format(this.format) : "";

      var $result = this.editControl = this._createTextBox();
      $result.val(value);
      return $result;
    },

    _createTextBox: function() {
      return $("<input>").attr("type", "text").val(new Date().format(this.format));
    },

    filterValue: function () {
      return this.dateToISO(this.filterControl.val());
    },

    insertValue: function () {
      return this.dateToISO(this.insertControl.val());
    },

    editValue: function () {
      return this.dateToISO(this.editControl.val());
    },

    dateToISO: function(d) {
      if (d == null || d == '')
        return null;
      var dt = d.split(" ")[0].split(".");
      if (dt[1].length < 2) dt[1] = '0' + dt[1];
      if (dt[2].length < 2) dt[2] = '0' + dt[2];
      dt = dt[2] + "-" + dt[1] + "-" + dt[0];
      var tm = d.split(" ")[1];
      if (tm == undefined || tm.length == 0) tm = '00:00:00';
      return new Date(dt + "T" + tm).toISOString();
    }
  });

  jsGrid.fields.date = jsGrid.DateField = DateField;

}(jsGrid, jQuery));

(function(jsGrid, $, undefined) {

    var TextField = jsGrid.TextField;

    function CustomField(config) {
        TextField.call(this, config);
    }

    CustomField.prototype = new TextField({
        t_header: function() { return TextField.prototype.headerTemplate.call(this);},
        t_item: function(value, item) { return TextField.prototype.itemTemplate.call(this, value, item);},
        t_filter: function() { return TextField.prototype.filterTemplate.call(this);},
        t_insert: function() { return TextField.prototype.insertTemplate.call(this);},
        t_edit: function(value, item) { return TextField.prototype.insertTemplate.call(this, value, item);},

        headerTemplate: function() {
          return this.t_header.call(this);
        },

        itemTemplate: function(value, item) {
          return this.t_item.call(this, value, item);
        },

        filterTemplate: function() {
          return this.t_filter.call(this);
        },

        insertTemplate: function() {
          return this.t_insert.call(this);
        },

        editTemplate: function(value, item) {
          return this.t_header.call(this, value, item);
        }
    });

    jsGrid.fields.custom = jsGrid.CustomField = CustomField;

}(jsGrid, jQuery));
